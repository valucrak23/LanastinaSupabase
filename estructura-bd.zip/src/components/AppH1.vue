        <template>
            <h1 class="mb-6 text-4xl text-crochet-text-primary font-bold">
                <slot />
            </h1>
        </template>